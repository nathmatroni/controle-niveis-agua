from colorama import Fore, Style, init

# Inicializa a biblioteca Colorama
init()

# Lista com os níveis e suas respectivas mensagens e cores
niveis_agua = [
    ("Nível 1 - Muito baixo (Crítico)", Fore.RED),
    ("Nível 2 - Baixo", Fore.YELLOW),
    ("Nível 3 - Médio", Fore.GREEN),
    ("Nível 4 - Alto", Fore.CYAN),
    ("Nível 5 - Muito alto (Alerta)", Fore.BLUE)
]


# Função responsável por definir a cor da mensagem conforme o nível
def verificar_nivel(nivel):
    if nivel >= 1 and nivel <= 5:
        mensagem, cor = niveis_agua[nivel - 1]
        print(cor + mensagem + Style.RESET_ALL)
    else:
        print("Nível inválido!")


# Simulação do monitoramento do reservatório
print("===== MONITORAMENTO DO RESERVATÓRIO =====\n")

for nivel in range(1, 6):
    verificar_nivel(nivel)
